# The routine shows how to delete declared newtype and redefine.
