#include<stdio.h>
#include<mpi.h>

int main( int argc, char* argv[] )
{







    return 0;
}
