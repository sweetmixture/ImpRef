#include<stdio.h>
#include<mpi.h>

int main( int argc, char* argv[] )
{
	
	for(int i=0;i<10;i++)
	{
		printf("%d\n",i);
	}


	return 0;
}
